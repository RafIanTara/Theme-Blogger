document.addEventListener("DOMContentLoaded", function() {
    
    const themeBtn = document.getElementById('theme-toggle-btn');
    const themeIcon = document.getElementById('theme-icon');
    const htmlTag = document.documentElement;
    
    const savedTheme = localStorage.getItem('bloggerTheme');
    if (savedTheme === 'light') {
      htmlTag.setAttribute('data-theme', 'light');
      if (themeIcon) themeIcon.textContent = '☀️';
    }

    if (themeBtn) {
        themeBtn.addEventListener('click', () => {
          let currentTheme = htmlTag.getAttribute('data-theme');
          if (currentTheme === 'light') {
            htmlTag.removeAttribute('data-theme');
            localStorage.setItem('bloggerTheme', 'dark');
            themeIcon.textContent = '🌙';
          } else {
            htmlTag.setAttribute('data-theme', 'light');
            localStorage.setItem('bloggerTheme', 'light');
            themeIcon.textContent = '☀️';
          }
        });
    }

    const textArray = [
        "System_Initializing...", 
        "Welcome RafBloger...", 
        "My name is Muhammad Rafa Firdaus...", 
        "students of Muhammadiyah 1 Metro...", 
        "This is My Bini....",
        "Enjoy Reading!"
    ];
    let textIndex = 0;
    let charIndex = 0;
    const typingDelay = 100;
    const erasingDelay = 50;
    const newTextDelay = 2000; 
    const typedTextSpan = document.getElementById("typed-text");

    function type() {
      if (!typedTextSpan) return;
      if (charIndex < textArray[textIndex].length) {
        typedTextSpan.textContent += textArray[textIndex].charAt(charIndex);
        charIndex++;
        setTimeout(type, typingDelay);
      } else {
        setTimeout(erase, newTextDelay);
      }
    }

    function erase() {
      if (!typedTextSpan) return;
      if (charIndex > 0) {
        typedTextSpan.textContent = textArray[textIndex].substring(0, charIndex - 1);
        charIndex--;
        setTimeout(erase, erasingDelay);
      } else {
        textIndex++;
        if (textIndex >= textArray.length) textIndex = 0;
        setTimeout(type, typingDelay + 1000);
      }
    }

    if(textArray.length) setTimeout(type, newTextDelay + 250);
});